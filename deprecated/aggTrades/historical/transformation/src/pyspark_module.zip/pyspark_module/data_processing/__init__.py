from .data_market_processor_GCS import (
    DataProcessor,
)
